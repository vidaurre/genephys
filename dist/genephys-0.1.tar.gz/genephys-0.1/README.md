# genephys
Generates synthetic electrophysiological data, with spontaneously time-varying amplitude and frequency, and various options to introduce different types of stimulus-driven effects..

See also readthedocs 
